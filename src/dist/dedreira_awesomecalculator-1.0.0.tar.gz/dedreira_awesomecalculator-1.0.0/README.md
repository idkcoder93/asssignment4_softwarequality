# Awesome Calculator
This is a basic python package project to play around with GitHub Actions, you can check the repository [here](https://github.com/dedreira/awesomecalculator)